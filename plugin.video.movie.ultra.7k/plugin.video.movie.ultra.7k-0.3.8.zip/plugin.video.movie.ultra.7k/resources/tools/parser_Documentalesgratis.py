# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Parser de Documentalesgratis.es para Movie Ultra 7K
# Version 0.1 (11.10.2015)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)



import os
import sys
import urllib
import urllib2
import re

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

import plugintools
import requests
from resources.tools.resolvers import *

playlists = xbmc.translatePath(os.path.join('special://userdata/playlists', ''))
temp = xbmc.translatePath(os.path.join('special://userdata/playlists/tmp', ''))

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

def miprueba2(params):
    plugintools.log("[%s %s] Ejecutando Parser de Documentalesgratis.es " % (addonName, addonVersion))

    name = 'Documentalesgratis.es'
    thumbnail = 'http://img.webme.com/pic/a/akimismo/bannerdocumentales2.png'
    fanart = 'http://i.ytimg.com/vi/OQVCXlZ0rDo/hqdefault.jpg'
    update = '19/10/2015 12:15'
    Autor = 'Movie Ultra 7K'
    
    r = requests.get("http://www.documentalesgratis.es/browse/")
    data = r.content
    #print data
    plugintools.add_item(action="",url="",title="[COLOR red][B]DocumentalesGratis[/B][/COLOR]",thumbnail=thumbnail,fanart=fanart,folder=True,isPlayable=False)
 
    bloque_documental = plugintools.find_multiple_matches(data,'<div class="thumb">(.*?)<span class="overlay"></span>')

 
 
    for item in bloque_documental:
     plugintools.log("item= "+item)
     url_documental=plugintools.find_single_match(item, 'href="(.*?)">')
     print bloque_documental
     titulo_documental=plugintools.find_single_match(item, 'alt="(.*?)"')
     caratula_documental=plugintools.find_single_match(item, 'src="(.*?)"')
     plugintools.add_item(action="miprueba_3", title=titulo_documental, url=url_documental, thumbnail=caratula_documental, folder=True, isPlayable=False)
  
def miprueba_3(params):
   plugintools.log("[%s %s] Obteniendo enlaces de Video: %s" % (addonName, addonVersion, repr(params)))
  
   url = params.get("url")
   caratula_documental = params.get("thumbnail")
   r = requests.get(url)
   data = r.content
   print data
	 
 
   bloque_enlaces=plugintools.find_single_match(data, '</div><!-- end .entry-header -->(.*?)<div id="details" class="section-box">')
   print bloque_enlaces
   url_documental=plugintools.find_single_match(bloque_enlaces,'src="(.*?)"')
 
  
   
   if url_documental.startswith("https://www.youtube.com/")== True:
      title = params.get("title")+ '[COLOR red][B] [Youtube][/COLOR][/B]'
      url_montada = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url='+url_documental+'%26referer='+'https://www.youtube.com/'
      plugintools.add_item(action="runPlugin", title=title, url=url_montada, thumbnail=caratula_documental, fanart=fanart, folder = False, isPlayable=True)
   
   elif url_documental.startswith("https://player.vimeo.com/")== True:
      title = params.get("title")+ '[COLOR red][I] [Vimeo][/COLOR][/I]'
      plugintools.add_item(action="vimeo", title=title, url=url_documental, thumbnail=caratula_documental, fanart=fanart, folder = False, isPlayable=True)
