from __main__ import *
baseurl='http://cricfree.tv/'
thumb='http://cricfree.tv/images/channelslist.png'
thumb='https://lazonasucia.files.wordpress.com/2014/03/cricfree.jpg'
fan='http://cricfree.tv/images/logosimg.png'
messs='plugintools.message("ERROR","[COLOR=yellow]Cambios en la web[/COLOR]","[COLOR=red](avisar en el foro)[/COLOR]")'
nolink='plugintools.message("ATENCION","[COLOR=yellow]Canal sin emicion[/COLOR]","[COLOR=red](no hay enlaces)[/COLOR]")'
def cric0(params):
 plugintools.add_item(title='[COLOR=green]C[COLOR white]ric[COLOR=green]F[COLOR white]ree[COLOR=green]TV[/COLOR]',thumbnail=fan,fanart=thumb,folder=False)
 plugintools.add_item(action='cric20',title='Deportes',thumbnail=fan,fanart=thumb,isPlayable=False,folder=True)
 plugintools.add_item(action='cric30',title='Programacion',thumbnail=fan,fanart=thumb,isPlayable=False,folder=True)
 plugintools.add_item(action='cric10',title='Canales',thumbnail=fan,fanart=thumb,isPlayable=False,folder=True)
def cric20(params):
 ref=baseurl;body='';jar='';body,jar=cric2(baseurl,ref,body,jar);
 try:
  r='<ul class="mcd-menu">(.*?)<\/ul>';w=plugintools.find_single_match(body,r);
  r='<a href="([^"]+).*?<strong>([^<]+)';w=plugintools.find_multiple_matches(body,r);
  for x,y in w:
   plugintools.add_item(action='cric21',title=str(y),url=str(x),thumbnail=fan,fanart=thumb,isPlayable=True,folder=True)
 except: exec(messs);sys.exit();
def cric30(params):
 ref=baseurl;body='';jar='';body,jar=cric2(baseurl,ref,body,jar);
 try:
  r='<div class="HomeTable">.*?<table>(.*?)<\/table>';w=plugintools.find_single_match(body,r);
  r='<tr>(.*?)<\/tr>';w=plugintools.find_multiple_matches(body,r);w=w[1:]
  for x in w:
   r='class="sport-icon ([^"]+).*?<td>([^<]+).*?class="matchtime".*?>([^<]+).*?<td>([^<]+).*?href="([^"]+).*?>([^<]+)';
   try:
    q=plugintools.find_multiple_matches(x,r);
    tit='[COLOR=green]'+q[0][2]+'/'+q[0][1].replace('-2015','')+' [COLOR=yellow]'+q[0][5]+'[COLOR=red] ('+q[0][0]+') [COLOR=white]'+q[0][3]+'[/COLOR]';
    plugintools.add_item(action='cric31',title=str(tit),url=str(q[0][4]),thumbnail=fan,fanart=thumb,isPlayable=True,folder=False)
   except: pass
 except: exec(messs);sys.exit();
def cric21(params):
 r='<div class="HomeTable">.*?<table>(.*?)<\/table>';q=[];y=[];ref=baseurl;body='';jar='';
 try:
  body,jar=cric2(params.get('url'),ref,body,jar);w=plugintools.find_single_match(body,r);
  r='<tr>(.*?)<\/tr>';w=plugintools.find_multiple_matches(body,r);w=w[1:]
 except: exec(messs);
 for x in w:
   r='class="sport-icon ([^"]+).*?<td>([^<]+).*?class="matchtime".*?>([^<]+).*?<td>([^<]+).*?href="([^"]+).*?>([^<]+)';
   try:
    q=plugintools.find_multiple_matches(x,r);
    tit='[COLOR=green]'+q[0][2]+'/'+q[0][1].replace('-2015','')+' [COLOR=yellow]'+q[0][5]+'[COLOR=red] ('+q[0][0]+') [COLOR=white]'+q[0][3]+'[/COLOR]';
    plugintools.add_item(action='cric31',title=str(tit),url=str(q[0][4]),thumbnail=fan,fanart=thumb,isPlayable=True,folder=False)
   except: pass
def cric31(params):
 r='<div class="WatchTable">.*?<tr>(.*?)<\/tr>';q=[];y=[];ref=baseurl;body='';jar='';
 try: body,jar=cric2(params.get('url'),ref,body,jar);w=plugintools.find_multiple_matches(body,r);print body,jar
 except: exec(messs);
 try: r='<a href="([^"]+).*?"shiny-button">([^<]+)';w=plugintools.find_multiple_matches(w[0],r);
 except: exec(messs);
 for x in w: q.append('[COLOR=green] ('+x[1]+')[/COLOR]');y.append(x[0]);
 if len(q)==0: exec(nolink);sys.exit();
 try:
  link=q;index=0;ch=0;
  index=plugintools.selector(link,title='[COLOR=green]C[COLOR white]ric[COLOR=green]F[COLOR white]ree[COLOR=green]TV[/COLOR]');
  ch=y[index];
  if ch:
   if index > -1: par={"tit":link[index],"link":ch};cric32(par);
 except KeyboardInterrupt: pass;
 except IndexError: raise;
def cric32(params):
 ref=baseurl;body='';jar='';url=params.get('link')
 try:
  body,jar=cric2(url,ref,body,jar);ref=url;
  r='(id|width|height|src)="?\'?([^"\']+)';w=plugintools.find_multiple_matches(body,r);w=w[:4];
  url='http://theactionlive.com/livegamecr.php?id='+w[0][1]+'&width='+w[1][1]+'&height='+w[2][1]+'&stretching='
  body,jar=cric2(url,ref,body,jar);ref=url;
  r='(id|width|height|src)="?\'?([^"\']+)';w=plugintools.find_multiple_matches(body,r);w=w[:4];
  url='http://biggestplayer.me/streamcr.php?id='+w[0][1]+'&width='+w[1][1]+'&height='+w[2][1]
  body,jar=cric2(url,ref,body,jar);ref=url;
  r='flashvars="file=([^\&]+).*?streamer=([^&]+)';w=plugintools.find_multiple_matches(body,r);
  url=w[0][1]+' playpath='+w[0][0]+' swfUrl=http://bernardotv.club/atdedead.swf live=1 token=#atd%#$ZH pageUrl='+ref;#print url
 except: exec(nolink);sys.exit();
 plugintools.play_resolved_url(url);sys.exit();
def cric10(params):
 ref=baseurl;body='';jar='';body,jar=cric2(baseurl,ref,body,jar);
 try:
  r='<li class="has-sub"><a href="([^"]+).*?<span class="channels-icon ([^"]+)';w=plugintools.find_multiple_matches(body,r);
  for x,y in w:
   tit=x.split('/');tit=tit[3].replace('live-stream','').replace('in-streaming','').replace('in-diretta','').replace('-',' ').capitalize();
   plugintools.add_item(action='cric1',title=tit,url=str(x),thumbnail=fan,fanart=thumb,isPlayable=True,folder=False)
 except: exec(messs);sys.exit();
def cric1(params):
 try:
  ref=baseurl;body='';jar='';body,jar=cric2(params.get('url'),ref,body,jar);
  r='<iframe.*?src="([^"]+)';url=plugintools.find_single_match(body,r);
  body,jar=cric2(url,ref,body,jar);ref=url;
  r='(id|width|height|src)="?\'?([^"\']+)';w=plugintools.find_multiple_matches(body,r);w=w[:4];
  url='http://theactionlive.com/livegamecr.php?id='+w[0][1]+'&width='+w[1][1]+'&height='+w[2][1]+'&stretching='
  body,jar=cric2(url,ref,body,jar);ref=url;
  r='(id|width|height|src)="?\'?([^"\']+)';w=plugintools.find_multiple_matches(body,r);w=w[:4];
  url='http://biggestplayer.me/streamcr.php?id='+w[0][1]+'&width='+w[1][1]+'&height='+w[2][1]
  body,jar=cric2(url,ref,body,jar);ref=url;
  r='flashvars="file=([^\&]+).*?streamer=([^&]+)';w=plugintools.find_multiple_matches(body,r);
  url=w[0][1]+' playpath='+w[0][0]+' swfUrl=http://bernardotv.club/atdedead.swf live=1 token=#atd%#$ZH pageUrl='+ref;
  plugintools.play_resolved_url(url);sys.exit();
 except: exec(nolink);sys.exit();
def cric2(url,ref,body,jar):
 request_headers=[];
 request_headers.append(['Referer',ref])
 request_headers.append(['User-Agent','Mozilla/5.0 (Windows NT 6.2; rv:34.0) Gecko/20100101 Firefox/34.0'])
 body,response_headers=plugintools.read_body_and_headers(url,headers=request_headers);print response_headers
 try: jar=[x[1] for x in response_headers if x[0]=='set-cookie'][0];
 except: jar='';pass
 return body,jar