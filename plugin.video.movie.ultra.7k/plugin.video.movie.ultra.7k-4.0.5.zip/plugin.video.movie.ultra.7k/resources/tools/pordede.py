# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Regex de Pordede para Movie Ultra 7K
# Version 0.1 (29/12/2015)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Librerías Plugintools por Jesús (www.mimediacenter.info)
#
#

import urlparse,urllib2,urllib,re
import os, sys

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

import plugintools
import requests

import traceback
from resources.tools.resolvers import *

web = "http://www.pordede.com"
referer = "http://www.pordede.com/"
fanart = 'https://dl.dropbox.com/s/q4rjyn2h7wvso8c/fondo%20pordede.jpg?'
thumbnail = 'https://dl.dropbox.com/s/1ehro3579ue96x4/pordede1.jpg' 
post = "LoginForm[username]="+plugintools.get_setting("pordede_user")+"&LoginForm[password]="+plugintools.get_setting("pordede_pwd")
DEFAULT_HEADERS = []
DEFAULT_HEADERS.append( ["User-Agent","Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6; es-ES; rv:1.9.2.12) Gecko/20101026 Firefox/3.6.12"] )
DEFAULT_HEADERS.append( ["Referer","http://www.pordede.com"] )

sc = "[COLOR white][B]";ec = "[/B][/COLOR]"
sc2 = "[COLOR red][B]";ec2 = "[/B][/COLOR]"
sc3 = "[COLOR green]";ec3 = "[/COLOR]"
sc4 = "[COLOR red][B]";ec4 = "[/COLOR]"
sc5 = "[COLOR blue]";ec5 = "[/COLOR]"
version = " [0.1]"

def pdd_findvideos(params):
    plugintools.log("[%s %s] Regex Pordede %s" % (addonName, addonVersion, repr(params)))

    page_url = params.get("page")
    plugintools.log("URL= "+page_url)

    if plugintools.get_setting("pordede_user") == "":
        plugintools.add_item(action="", title="Habilita Tu Cuenta De Pordede En La Configuración", folder=False, isPlayable=False)
    else:
        url = "http://www.pordede.com/site/login"
        post = "LoginForm[username]="+plugintools.get_setting("pordede_user")+"&LoginForm[password]="+plugintools.get_setting("pordede_pwd")
        headers = DEFAULT_HEADERS[:]
       
        body,response_headers = plugintools.read_body_and_headers(url,post=post)
        
        try:
            if os.path.exists(temp+'pordede.com') is True:
                print "Eliminando carpeta caché..."
                os.remove(temp+'pordede.com')
        except: pass
        
        headers = DEFAULT_HEADERS[:]
        #headers.append(["X-Requested-With","XMLHttpRequest"])
        body,response_headers = plugintools.read_body_and_headers(page_url,headers=headers)
        #print body
        try:
            info_user = plugintools.find_single_match(body,'<div class="userinfo">(.*?)</div>')
            usuario = plugintools.find_single_match(info_user,'<div class="friendMini shadow" title="(.*?)"')
            avatar = plugintools.find_single_match(info_user,'src="(.*?)"')

            bloq_fich = plugintools.find_single_match(body,'<div class="sidebar">(.*?)<h2 class="info">Más información</h2>')
            logo = plugintools.find_single_match(bloq_fich,'onerror="this.src=\'/images/logo.png\'" src="(.*?)"')
            if logo =="":
                logo = thumbnail
            fondo = plugintools.find_single_match(body,'onerror="controller.noBigCover.*?src="(.*?)"')
            if fondo =="":
                fondo = fanart
            info_vid = plugintools.find_single_match(body,'<div class="main">(.*?)<div class="centered">')
            sinopsis = plugintools.find_single_match(info_vid,'style="max-height: 140px;overflow:hidden">(.*?)</div>').strip()
            datamovie = {}
            datamovie["Plot"] = sinopsis
            if "peli" in page_url:
                title = plugintools.find_single_match(info_vid,'<h1>(.*?)</h1>').replace("&amp;","&").upper()
                id_ajax = plugintools.find_single_match(body,'data-model="peli" data-id="([^"]+)">') #id necesario marcado como visto
                #url y parametros para marcar como visto (params Extra)
                parametros_ajax = 'http://www.pordede.com/ajax/mediaaction|model=peli&id='+id_ajax+'&action=status&value=3|'+page_url 
                status = plugintools.find_single_match(body,'controller.userStatus(.*?);').split(',') #marcada en la web
                #comprobado si esta marcada como vista
                if "3" in status[2]:
                    title = plugintools.find_single_match(info_vid,'<h1>(.*?)</h1>').replace("&amp;","&").upper()
                    titlefull = sc5+"[B]"+title+"[/B]"+ec5+sc2+" [Vista]"+ec2
                else:
                    titlefull = sc5+"[B]"+title+"[/B]"+ec5 
            elif "serie" in page_url:
                title = plugintools.find_single_match(info_vid,'<h1>(.*?)<span class="titleStatus">').replace("&amp;","&").upper()
                titlefull = sc5+"[B]"+title+"[/B]"+ec5
            
            punt = plugintools.find_single_match(bloq_fich,'<span class="puntuationValue" data-value="(.*?)"')
            year_duration = plugintools.find_single_match(bloq_fich,'<p class="info">(.*?)</p>.*?<p class="info">(.*?)</p>')
            bloq_repart = plugintools.find_single_match(body,'<h2>reparto</h2>(.*?)class="viewmore"><span>')
            url_links = plugintools.find_single_match(info_vid,'<button class="defaultPopup big" href="(.*?)"')
            url_linksfull = web + url_links
            
            plugintools.add_item(action="",url="",title="[COLOR blue][B]Pordede [COLOR green]Versión"+version+""+sc4+"[/B]"+ec4,thumbnail=thumbnail,fanart=fanart,folder=False,isPlayable=False)
            plugintools.add_item(action="",url="",title=sc2+"Usuario: "+usuario+ec2,thumbnail=avatar,fanart=fanart,folder=False,isPlayable=False)
            plugintools.add_item(action="",url="",title="",thumbnail=logo,fanart=fondo,folder=False,isPlayable=False)
            plugintools.addPeli(action="",title=titlefull,plot="",url="",thumbnail=logo,fanart=fondo,info_labels=datamovie,folder=False,isPlayable=False)
            if url_links !="":
                plugintools.add_item(action="pordede_server",url=url_linksfull,title=sc5+"Ir a los Enlaces >>"+ec5,thumbnail=logo,fanart=fondo,extra=parametros_ajax,folder=True,isPlayable=False)
            else:
                plugintools.add_item(action="pordede_serie",url=page_url,title=sc5+"Ir a los Episodios >>"+ec5,thumbnail=logo,fanart=fondo,folder=True,isPlayable=False)

            plugintools.add_item(action="",url="",title=sc+"Puntuacion Usuarios Pordede: "+ec+sc3+punt+ec3,thumbnail=logo,fanart=fondo,folder=False,isPlayable=False)
            plugintools.add_item(action="",url="",title=sc+"Año: "+ec+sc3+year_duration[0]+ec3+"  "+sc+"Duracion: "+ec+sc3+year_duration[1]+ec3,thumbnail=logo,fanart=fondo,folder=False,isPlayable=False)
            plugintools.add_item(action="",url="",title=sc5+"Reparto: "+ec5,thumbnail=logo,fanart=fondo,folder=False,isPlayable=False)
            repart = plugintools.find_multiple_matches(bloq_repart,'<div class="starThumbnail">(.*?)<div class="star">')

            for item in repart:
                info = plugintools.find_single_match(item,'<a class="ellipsis defaultLink" href="([^"]+)">([^<]+)</a><br/><span>([^<]+)</span>')
                info1 = info[1].replace("&nbsp;",sc5+"No Hay Datos"+ec5).replace("&quot;"," ").replace("#","") 
                info2 = info[2].replace("&nbsp;",sc5+"No Hay Datos"+ec5).replace("&quot;"," ").replace("#","") 
                plugintools.add_item(action="",url="",title=sc+info1+": "+ec+sc3+info2+ec3,thumbnail=logo,fanart=fondo,folder=False,isPlayable=False)               
        except:
            pass
            errormsg = plugintools.message("Movie Ultra 7K",sc4+"!!!!Atención"+ec4+"[CR]Revise la url del video si persiste el Error[CR]el regex o la Web no funcionan[CR]Movie Ultra 7K no puede cargar los datos.")
        
    params["thumbnail"] = logo
    params["fanart"] = fondo

def pordede_serie(params):
    plugintools.log("[%s %s] Regex Pordede %s" % (addonName, addonVersion, repr(params)))

    url = params.get("url")
    logo = params.get("thumbnail")
    fondo = params.get("fanart")

    plugintools.add_item(action="",url="",title="[COLOR blue][B]Pordede [COLOR green]Versión"+version+""+sc4+"[/B]"+ec4,thumbnail=thumbnail,fanart=fanart,folder=False,isPlayable=False)
    headers = DEFAULT_HEADERS[:]
    body,response_headers = plugintools.read_body_and_headers(url,headers=headers)

    temporada = '<div class="checkSeason"[^>]+>([^<]+)<div class="right" onclick="controller.checkSeason(.*?)\s+</div></div>'
    itemtemporadas = re.compile(temporada,re.DOTALL).findall(body)

    for nombre_temporada,bloque_episodios in itemtemporadas:
        patron  = '<span class="title defaultPopup" href="([^"]+)"><span class="number">([^<]+)</span>([^<]+)</span>(\s*</div>\s*<span[^>]*><span[^>]*>[^<]*</span><span[^>]*>[^<]*</span></span><div[^>]*><button[^>]*><span[^>]*>[^<]*</span><span[^>]*>[^<]*</span></button><div class="action([^"]*)" data-action="seen">)?'
        matches = re.compile(patron,re.DOTALL).findall(bloque_episodios)
        num_temp = nombre_temporada.replace("Temporada","").replace("Extras","Extras 0")
        plugintools.add_item(action="",url="",title=sc2+"-- "+nombre_temporada+" --"+ec2,thumbnail=logo,fanart=fondo,folder=True,isPlayable=False)
        for item in matches:
            id_ajax = plugintools.find_single_match(item[0],'/links/viewepisode/id/([0-9]*)')  #id necesario marcado como visto
            #print id_ajax
            parametros_ajax = 'http://www.pordede.com/ajax/action|model=episode&id='+id_ajax+'&action=seen&value=1|'+url #url y parametros para marcar como visto (params Extra)
            visto = plugintools.find_single_match(item[3],'</button><div class="([^"]+)"')
            if 'action active' in visto:
                title = item[2]
                titlefull = sc+num_temp+"x"+item[1]+" -- "+title+ec+sc5+"[B] [Visto][/B]"+ec5
            else:
                title = item[2]
                titlefull = sc+num_temp+"x"+item[1]+" -- "+title+ec
            url = web+item[0]
            #print url
            plugintools.add_item(action="pordede_server",url=url,title=sc+titlefull+ec,thumbnail=logo,fanart=fondo,extra=parametros_ajax,folder=True,isPlayable=False)
                                                         
def pordede_server(params):
    plugintools.log("[%s %s] Regex Pordede %s" % (addonName, addonVersion, repr(params)))

    parametros_ajax = params.get("extra")  #Recibe los parametros necesarios para marcar como visto (split '|')
    url = params.get("url")
    logo = params.get("thumbnail")
    fondo = params.get("fanart")
    
    plugintools.add_item(action="",url="",title="[COLOR blue][B]Pordede [COLOR green]Versión"+version+""+sc4+"[/B]"+ec4,thumbnail=thumbnail,fanart=fanart,folder=False,isPlayable=False)
    body,response_headers = plugintools.read_body_and_headers(url) 
    bloq_aport = plugintools.find_single_match(body,'<ul class="linksList">(.*?)<ul class="linksList">')
    aport = plugintools.find_multiple_matches(bloq_aport, '<a target="_blank" class="a aporteLink done"(.*?)</a>')

    for item in aport:
        link_ok = plugintools.find_single_match(item,'class="num green"><span data-num="(.*?)"')
        #print link_ok
        link_ko = plugintools.find_single_match(item,'class="num red"><span data-num="(.*?)"')
        #print link_ko
        if int(link_ok) >= int(link_ko):

            name_server = plugintools.find_single_match(item,'popup_(.*?)">').replace(".png","").capitalize()
            url = plugintools.find_single_match(item,'href="(.*?)"')
            url_aport = web+url
            #print url_aport
    
            idiomas = re.compile('<div class="flag([^"]+)">([^<]+)</div>',re.DOTALL).findall(item)
            idioma_0 = (idiomas[0][0].replace("&nbsp;","").strip() + " " + idiomas[0][1].replace("&nbsp;","").strip()).strip()
            if len(idiomas) > 1:
                idioma_1 = (idiomas[1][0].replace("&nbsp;","").strip() + " " + idiomas[1][1].replace("&nbsp;","").strip()).strip()
                idioma = idioma_0+" - "+idioma_1
            else:
                idioma_1 = ''
                idioma = idioma_0
            idioma=idioma.replace("spanish", "Esp").replace("english", "Eng").replace("spanish SUB", "Sub-Esp").replace("english SUB", "Sub-Eng").replace("german", "Ger")
            calidad_video = plugintools.find_single_match(item,'<div class="linkInfo quality"><i class="icon-facetime-video"></i>([^<]+)</div>').strip()
            calidad_audio = plugintools.find_single_match(item,'<div class="linkInfo qualityaudio"><i class="icon-headphones"></i>([^<]+)</div>').strip()
            title = sc+name_server+ec+" "+sc2+" ["+idioma+"] "+ec2+" "+sc3+"(OK: "+link_ok+") "+ec3+" "+sc4+"(KO: "+link_ko+") "+ec4+sc+"Video: "+ec+sc5+calidad_video+ec5+sc+"  Audio: "+ec+sc5+calidad_audio+ec5

            plugintools.add_item(action="pordede_checkvist",url=url_aport,title=title,thumbnail=logo,fanart=fondo,extra=parametros_ajax,folder=False,isPlayable=True)
            
def pordede_checkvist(params):
    
    parametros_ajax = params.get("extra").split('|') #Recibe los parametros necesarios para marcar como visto (split '|')
    url_post = parametros_ajax[0]
    post = parametros_ajax[1] #El post viene montado desde la funcion
    url = parametros_ajax[2]

    #print url_post,post,url
    headers = {"Host":"www.pordede.com","User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:43.0) Gecko/20100101 Firefox/43.0","Referer": url}
    body,response_headers = plugintools.read_body_and_headers(url_post,post=post,headers=headers) #Enviando los parametros para marcar visto
    url = params.get("url")
    title = params.get("title")
    params["url"] = url
    params["title"] = title
    pordede_link(params)    
         
def pordede_link(params):
   
    link = params.get("url")
    title = params.get("title")
    
    body,response_headers = plugintools.read_body_and_headers(link) #, post=post)
    goto = plugintools.find_single_match(body,'<p class="nicetry links">(.*?)target="_blank"')
    link_redirect = plugintools.find_single_match(goto,'<a href="(.*?)"')
    link_redirect = web + link_redirect
    
    try:
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:43.0) Gecko/20100101 Firefox/43.0","Referer": link}
        body,response_headers = plugintools.read_body_and_headers(link_redirect) 
        #print body
        for i in response_headers:
		 if i[0]=='location':location=i[1]
        if location:print '$'*20+'- Movie Ultra 7K -'+'$'*20,location,'$'*59
        
        if "allmyvideos" in location:
            media_url = location
            params["url"]=media_url
            allmyvideos(params)

        elif "bitvid" in location:
            media_url = location
            params["url"]=media_url
            bitvid(params)

        elif "flashx" in location:
            media_url = location
            params["url"]=media_url
            flashx(params)

        elif "gamovideo" in location:
            media_url = location
            params["url"]=media_url
            gamovideo(params)

        elif "moevideos" in location:
            media_url = location
            params["url"]=media_url
            moevideos(params)
        
        elif "netu.tv" in location:
            media_url = location
            params["url"]=media_url
            netu(params)
   
        elif "nowvideo" in location:
            media_url = location
            params["url"]=media_url
            nowvideo(params)

        elif "ok.ru" in location:
            media_url = location
            params["url"]=media_url
            okru(params)

        elif "played.to" in location:
            media_url = location
            params["url"]=media_url
            playedto(params)
                 
        elif "powvideo" in location:
           media_url = location
           params["url"]=media_url
           powvideo(params)

        elif "rocvideo" in location:
            media_url = location
            params["url"]=media_url
            rocvideo(params)

        elif "streamable" in location:
            media_url = location
            params["url"]=media_url
            streamable(params)
                      
        elif "streamcloud" in location:
            media_url = location
            params["url"]=media_url
            streamcloud(params)

        elif "streamin.to" in location:
            media_url = location
            params["url"]=media_url
            streaminto(params)
                
        elif "videomega" in location:
            media_url = location
            params["url"]=media_url
            videomega(params)

        elif "Video.tt" in location:
            media_url = location
            params["url"]=media_url
            videott(params)

        elif "videoweed" in location:
            media_url = location
            params["url"]=media_url
            videoweed(params)
   
        elif "vidspot" in location:
            media_url = location
            params["url"]=media_url
            vidspot(params)

        elif "vidto.me" in location:
            media_url = location
            params["url"]=media_url
            vidtome(params)

        elif "vk" in location:
            media_url = location
            params["url"]=media_url
            vk(params)

        elif "waaw" in location:
            media_url = location
            params["url"]=media_url
            waaw(params) 
                
    except: pass

# <<----------------------------------------------------------------------------------------------------------------------------------------------------->>


   
    
   


   
    


    
