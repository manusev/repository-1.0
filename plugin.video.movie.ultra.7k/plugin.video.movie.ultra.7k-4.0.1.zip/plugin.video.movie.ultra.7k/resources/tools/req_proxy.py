# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Conexión proxy con Movie Ultra 7K
# Version 0.1 (18.10.2014)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)


import os
import sys
import urllib
import urllib2
import re

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

import plugintools, xbmcplugin, requests
from resources.tools.resolvers import *
from __main__ import *


playlists = xbmc.translatePath(os.path.join('special://userdata/playlists', ''))
temp = xbmc.translatePath(os.path.join('special://userdata/playlists/tmp', ''))

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")



def req_proxy0(params):
    plugintools.log("[%s %s] Iniciando proxy... " % (addonName, addonVersion))

    page_url="http://allmyvideos.net/o1bliexgkpz0"

    import requests
    baseurl = 'http://incloak.es/proxy-list/?maxtime=300'
    ref = 'http://incloak.es/proxy-list/'
    data = gethttp_referer_headers(baseurl,ref)
    plugintools.log("data= "+data)

    bloque_ips = plugintools.find_single_match(data, 'Lea las instrucciones para su navegador(.*?)</script>')
    plugintools.log("bloque_ips= "+bloque_ips)
    proxy_id = plugintools.find_multiple_matches(bloque_ips, '<tr>(.*?)</tr>')

    i = 0
    
    for entry in proxy_id:
        plugintools.log("entry= "+entry)
        ip = plugintools.find_single_match(entry, '<td class=tdl>(.*?)</td>')
        plugintools.log("ip= "+ip)
        i = i + 1
        if ip != "":
            if i <= 10:
                country = plugintools.find_single_match(entry, '<div class=flag style="background-position[^>]+>(.*?)</div>')
                plugintools.log("country= "+country)
                #latency = plugintools.find_single_match(entry, '<div style="background-position[^>]+>(.*?)</div>')
                #checked = plugintools.find_single_match(entry, '<td class=tdr(.*?)</td>')                
                #plugintools.log("latency= "+latency)
                #plugintools.log("checked= "+checked)
                print i

                try:
                    proxies = {}
                    proxies["http"]=ip
                    proxies["https"]=ip
                    print proxies
                    url_fixed = page_url.split("/")
                    url_fixed = 'http://www.allmyvideos.net/' +  'embed-' + url_fixed[3] +  '.html'
                    plugintools.log("url_fixed= "+url_fixed)
                    r = requests.get(url_fixed, proxies=proxies, timeout=4)
                    data = r.text
                    print data
                    url_media = plugintools.find_single_match(data, '"file" : "(.*?)"')
                    if url_media != "":
                        plugintools.log("URL= "+url_media)
                        with open(temp + 'output.avi', 'wb') as handle:
                            response = requests.get(url_media, proxies=proxies, stream=True)

                            if not response.ok:
                                print "Something went wrong..."
                                # Something went wrong

                            for block in response.iter_content(1024):
                                handle.write(block)
                                                
                        break                        

                except: pass


    #plugintools.add_item(action="play", title="url", url=temp+'output.avi', folder="False", isPlayable="True")


    
def gethttp_referer_headers(url,ref):
    plugintools.log("url= "+url)
    plugintools.log("ref= "+ref)
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Intel Mac OS X 10_8_3) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.65 Safari/537.31"])
    request_headers.append(["Referer", ref])
    body,response_headers = plugintools.read_body_and_headers(url, headers=request_headers)      
    return body
