# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Parser de Pelis24.com para Movie Ultra 7K
# Version 0.1 (10.10.2015)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)



import os
import sys
import urllib
import urllib2
import re

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

import plugintools
import requests
from resources.tools.resolvers import *

playlists = xbmc.translatePath(os.path.join('special://userdata/playlists', ''))
temp = xbmc.translatePath(os.path.join('special://userdata/playlists/tmp', ''))

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

def miprueba(params):
 plugintools.log("[%s %s]" % (addonName, addonVersion))
 logo = 'http://pepecine.com/assets/images/logo.png'
 fondo = 'http://www.savor.es/imagenes/savor18129.jpg'
 r = requests.get("http://pepecine.com/")
 data = r.content
 print data

  
 plugintools.add_item(action="",url="",title="[COLOR red]                  Pepe[/COLOR]Cine", thumbnail=logo, fanart=fondo, folder=True, isPlayable=False)
 plugintools.add_item(action="",url="",title="[COLOR darkred]              ===========[/COLOR]", thumbnail=logo, fanart=fondo, folder=True, isPlayable=False)
 
 bloque_peli = plugintools.find_multiple_matches(data,'<div class="flip-container">(.*?)</figure>')
 
 for peli in bloque_peli:
   plugintools.log("peli= "+peli)
   url_peli=plugintools.find_single_match(peli, 'href="(.*?">)')
   titulo_peli=plugintools.find_single_match(peli, 'alt="(.*?)" class=')
   caratula_peli=plugintools.find_single_match(peli, '<img src="(.*?)" alt=')
   plugintools.log("titulo_peli= "+titulo_peli)
   plugintools.log("url_peli= "+url_peli)
   plugintools.log("caratula_peli= "+caratula_peli)
   plugintools.add_item(action="miprueba_1", title=titulo_peli, url=url_peli, thumbnail=caratula_peli, folder=True, isPlayable=False)
   
   
def miprueba_1(params):
 plugintools.log("[%s %s] Vamos a obtener los enlaces de Video de la peli: %s" % (addonName, addonVersion, repr(params)))
 
 url = params.get("url")
 r = requests.get(url)
 data = r.content
 print data
 
 bloque_enlaces=plugintools.find_single_match(data, '<li class="active" onclick="firstLI(.*?)</tbody>')
 print bloque_enlaces
 url_peli=plugintools.find_multiple_matches(bloque_enlaces, "app.utils.getFavicon\(\'([^']+)")
 for cada_peli in url_peli:
  plugintools.log("url_peli= "+cada_peli)
  if cada_peli.startswith("http://player.vimple.ru")== True:
   title = params.get("title") + '[COLOR cyan][I] [Vimple.ru][/COLOR][/I]'	
  elif cada_peli.startswith("http://powvideo.net")== True:
   title = params.get("title") + '[COLOR cyan][I] [Powvideo][/COLOR][/I]'
  elif cada_peli.startswith("http://hqq.tv")== True:
   title = params.get("title") + '[COLOR cyan][I] [hqq.tv][/COLOR][/I]'
  elif cada_peli.startswith("http://ok.ru")== True:
   title = params.get("title") + '[COLOR cyan][I] [ok.ru][/COLOR][/I]'
  elif cada_peli.startswith("http://flashx.tv")== True:
   title = params.get("title") + '[COLOR cyan][I] [flashx.tv][/COLOR][/I]'
  elif cada_peli.startswith("http://streamin.to")== True:
   title = params.get("title") + '[COLOR cyan][I] [streamin.to][/COLOR][/I]'
  if cada_peli.startswith("http://videomega.tv")== True:
   title = params.get("title") + '[COLOR cyan][I] [Videomega.tv][/COLOR][/I]'
  plugintools.add_item(action="streaminto",title=title, url=cada_peli, thumbnail=params.get("thumbnail"), folder=False, isPlayable=True)
 #elif plugintools.add_item(action="viple",title=title, url=cada_peli, thumbnail=params.get("thumbnail"), folder=False, isPlayable=True)
 #elif plugintools.add_item(action="hqqtv",title=title, url=cada_peli, thumbnail=params.get("thumbnail"), folder=False, isPlayable=True) 
 #elif plugintools.add_item(action="okru",title=title, url=cada_peli, thumbnail=params.get("thumbnail"), folder=False, isPlayable=True)
 #elif plugintools.add_item(action="flashx.tv",title=title, url=cada_peli, thumbnail=params.get("thumbnail"), folder=False, isPlayable=True)
 #elif plugintools.add_item(action="powvideo",title=title, url=cada_peli, thumbnail=params.get("thumbnail"), folder=False, isPlayable=True)
 #elif plugintools.add_item(action="videomega",title=title, url=cada_peli, thumbnail=params.get("thumbnail"), folder=False, isPlayable=True)
