# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Movie Ultra 7K
# Version 0.2 (18.03.2015)
# añadidos EPG y sinop (qQ)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)
from __main__ import *
from epg_miguiatv import *
from epg_elmundo import *
tit='[COLOR lightyellow]Wuarron[/COLOR]'
thumb='http://oi58.tinypic.com/2010vvo.jpg';fan='http://wallmobi.net/uploads/pictures/abstract/172-gold-texture.jpg'
epgmenu=plugintools.get_setting("warronepg");synmenu=plugintools.get_setting("warronsyn");
servoff='plugintools.message("ATENCION","[COLOR=yellow]Server OFF!!![/COLOR]")'
def wuarronlin10(params):
    url='https://dl.dropbox.com/s/hjk5yig3o4b5rd7/WarroParser.m3u'
    fan='http://wallmobi.net/uploads/pictures/abstract/172-gold-texture.jpg'
    try: body = plugintools.read(url)     
    except: pass
    matches = plugintools.find_multiple_matches(body, '#EXTINF:-1,(.*?)m3u8')
    #Comprobamos estado del servicio
    url2='http://digitele.premiumhostingweb.com/';#No creo que sirve...
    try: estado=plugintools.read(url2);estado='ON';
    except: estado='OFF'
    plugintools.add_item(action="",title=tit+'[COLOR red][I][B] '+estado+'[/B][/I][/COLOR]',thumbnail=thumb,fanart=fan,folder=False,isPlayable=False)  

    for entry in matches:
        #plugintools.log("entry= "+entry)
        title_line = plugintools.find_single_match(entry, '(.*?)\n')
        items = []
        items = m3u_items0(title_line)
        title_channel = entry.split(",")
        title_channel = title_channel[0].replace('@','');
        url_channel = plugintools.find_single_match(entry, '\n(.*?)index')
        url_channel = url_channel+'index.m3u8'
        url_fixed = url_channel.split("/")
        channel_id = url_fixed[3];plott='';plot=('00:00','N/A','00:00','N/A');sin='';fan='';syn='';
        if epgmenu=='true':
         try:
		  plot,fan,syn=dict_ch_name(channel_id);'''PRINTA ESTO PARA VER TODO LO QUE SALE'''#print 'process_sin',syn;
		  for i in range(0,len(plot),2): plott+='[CR]'+plot[i]+' '+plot[i+1]
		  if synmenu=='true': plott+=syn; '''comenta esto para quitar la parte de syn!!!'''
         except:
          try:
		   plot=epg_now(channel_id);
		   for i in range(0,len(plot),2): plott+='[CR]'+plot[i]+plot[i+1]
          except: fan='';plott='';plot=('00:00','N/A','00:00','N/A');pass
         title='[COLORwhite]'+title_channel+' [/COLOR][COLORgreen][I]\n'+plot[2]+' '+plot[3]+'[/I][/COLOR]';show='4';
        else: title='[COLORwhite]'+title_channel+'[/COLOR]';show='2';
        thumbnail = items[0]
        fanart = items[1];
        #print sin
        if fan: fanart=fan;
		# Control modo de vista
        plugintools.modo_vista(show);
        plugintools.add_item(action="wuarron_token0",plot=plott,title=title,url=url_channel,thumbnail=thumbnail,fanart=fanart,folder=False,isPlayable=True)
def m3u_items0(title):
    thumbnail = art + 'icon.png'
    fanart = art + 'fanart.jpg'
    only_title = title

    if title.find("tvg-logo") >= 0:
        thumbnail = re.compile('tvg-logo="(.*?)"').findall(title)
        num_items = len(thumbnail)
        if num_items == 0: thumbnail = 'm3u.png'
        else: thumbnail = thumbnail[0]
        only_title = only_title.replace('tvg-logo="', "")
        only_title = only_title.replace(thumbnail, "")

    if title.find("tvg-wall") >= 0:
        fanart = re.compile('tvg-wall="(.*?)"').findall(title)
        fanart = fanart[0]
        only_title = only_title.replace('tvg-wall="', "")
        only_title = only_title.replace(fanart, "")

    try:
        if title.find("imdb") >= 0:
            imdb = re.compile('imdb="(.*?)"').findall(title)
            imdb = imdb[0]
            only_title = only_title.replace('imdb="', "")
            only_title = only_title.replace(imdb, "")
        else: imdb = ""
    except: imdb = ""

    try:
        if title.find("dir") >= 0:
            dir = re.compile('dir="(.*?)"').findall(title)
            dir = dir[0]
            only_title = only_title.replace('dir="', "")
            only_title = only_title.replace(dir, "")
        else: dir = ""
    except: dir = ""

    try:
        if title.find("wri") >= 0:
            writers = re.compile('wri="(.*?)"').findall(title)
            writers = writers[0]
            only_title = only_title.replace('wri="', "")
            only_title = only_title.replace(writers, "")
        else: writers = ""
    except: writers = ""

    try:
        if title.find("votes") >= 0:
            num_votes = re.compile('votes="(.*?)"').findall(title)
            num_votes = num_votes[0]
            only_title = only_title.replace('votes="', "")
            only_title = only_title.replace(num_votes, "")
        else: num_votes = ""
    except: num_votes = ""

    try:
        if title.find("plot") >= 0:
            plot = re.compile('plot="(.*?)"').findall(title)
            plot = plot[0]
            only_title = only_title.replace('plot="', "")
            only_title = only_title.replace(plot, "")
        else: plot = ""
    except: plot = ""

    try:
        if title.find("genre") >= 0:
            genre = re.compile('genre="(.*?)"').findall(title)
            genre = genre[0]
            only_title = only_title.replace('genre="', "")
            only_title = only_title.replace(genre, "")
            print 'genre',genre
        else: genre = ""
    except: genre = ""

    try:
        if title.find("time") >= 0:
            duration = re.compile('time="(.*?)"').findall(title)
            duration = duration[0]
            only_title = only_title.replace('time="', "")
            only_title = only_title.replace(duration, "")
            print 'duration',duration
        else: duration = ""
    except: duration = ""

    try:
        if title.find("year") >= 0:
            year = re.compile('year="(.*?)"').findall(title)
            year = year[0]
            only_title = only_title.replace('year="', "")
            only_title = only_title.replace(year, "")
            print 'year',year
        else: year = ""
    except: year = ""

    if title.find("group-title") >= 0:
        cat = re.compile('group-title="(.*?)"').findall(title)
        if len(cat) == 0: cat = ""
        else: cat = cat[0]
        plugintools.log("m3u_categoria= "+cat)
        only_title = only_title.replace('group-title=', "")
        only_title = only_title.replace(cat, "")
    else: cat = ""

    if title.find("tvg-id") >= 0:
        title = title.replace('”', '"')
        title = title.replace('“', '"')
        tvgid = re.compile('tvg-id="(.*?)"').findall(title)
        print 'tvgid',tvgid
        tvgid = tvgid[0]
        plugintools.log("m3u_categoria= "+tvgid)
        only_title = only_title.replace('tvg-id=', "")
        only_title = only_title.replace(tvgid, "")
    else: tvgid = ""

    if title.find("tvg-name") >= 0:
        tvgname = re.compile('tvg-name="(.*?)').findall(title)
        tvgname = tvgname[0]
        plugintools.log("m3u_categoria= "+tvgname)
        only_title = only_title.replace('tvg-name=', "")
        only_title = only_title.replace(tvgname, "")
    else: tvgname = ""
    only_title = only_title.replace('"', "").replace('@', "").strip()
    return thumbnail, fanart, cat, only_title, tvgid, tvgname, imdb, duration, year, dir, writers, genre, num_votes, plot
def wuarron_token0(params):
    url_fixed = params.get("url")
    channel_id = params.get("plot")
    url = 'http://d.premiumhostingweb.com/secure-json.php?channel='+channel_id
    referer = 'http://d.premiumhostingweb.com/';#http://ks305163.kimsufi.com/
    data,heads = gethttp_referer_headers0(url,referer)
    #plugintools.log("data= "+data);print heads
    channel_id = plugintools.find_single_match(data, '"channel":"([^"]+)')
    token_id = plugintools.find_single_match(data, '"token":"([^"]+)')
    expire_id = plugintools.find_single_match(data, '"expire":"([^"]+)')
    url = url_fixed+'?st='+token_id+'&e='+expire_id
    url=url.strip()
    #print url
    plugintools.play_resolved_url(url)
def gethttp_referer_headers0(url,referer):
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_3) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.65 Safari/537.31"])
    request_headers.append(["Referer", referer])
    data,response_headers = plugintools.read_body_and_headers(url, headers=request_headers)      
    return data,response_headers
