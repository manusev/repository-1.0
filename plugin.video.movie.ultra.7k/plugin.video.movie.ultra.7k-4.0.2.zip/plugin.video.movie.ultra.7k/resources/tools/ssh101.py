# -*- coding: utf-8 -*-
#--------------------------------------------------------
#  Movie Ultra 7K
# Version 0.0.1 (12.11.2014)
#   !!! Intentar NO compartir este archivo !!!
#--------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
#--------------------------------------------------------
import os,sys,urllib,urllib2,re,cookielib,hashlib,time
import xbmc,sys,xbmcgui,xbmcaddon,xbmcplugin,plugintools
from plugintools import *
w='aHR0cDovLzIxNi42Ni44My4yLw==';q='L3BsYXlsaXN0Lm0zdTh8VXNlci1BZ2VudD0iTGF2ZjUzLjMyLjEwMCI=';
def s0(params):
 yi='http://stream.ssh101.com/hls/';q=plugintools.read(yi);
 r='<.*?icons\/unknown\.gif.*?href="([^"]+)';y=plugintools.find_multiple_matches(q,r);
 for x in y:
   w='\d{2}([^\.]+)';w=plugintools.find_single_match(x,w);
   plugintools.add_item(action="play",title=w.title(),url=str(yi+x),thumbnail="",fanart="",isPlayable=True,folder=False)