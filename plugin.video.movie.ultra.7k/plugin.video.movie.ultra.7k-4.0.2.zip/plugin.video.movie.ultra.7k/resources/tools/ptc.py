# -*- coding: utf-8 -*-
#--------------------------------------------------------
#  Movie Ultra 7K
# Version 0.0.1 (26.10.2014)
#--------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
#--------------------------------------------------------
#
#http://verdirectotv.com/carrusel/tv.html
#http://cinestrenostv.tv/carrusel/tv.html
#http://tvenganchado.com/parrilla/
#http://juanintv.net
#http://channel.verlatelegratis.net/canalespropios.php
#http://streamingfreetv.net/
#

from __main__ import *
spd=xbmcaddon.Addon('plugin.video.SportsDevil')
spd_dir=xbmc.translatePath(spd.getAddonInfo('path')+'\\lib');#print p2p_dir
#sys.path.append(spd_dir);import parser as SpDev;
#burl='http://pontucanal.net/'
burl='http://cinestrenostv.tv/carrusel/tv.html'
barl='http://cinestrenostv.tv/'

def ptc0(params):
 mssg='buscando programas...';timp=1000;exec(dlg);
 plugintools.add_item(title='*** '+params['title']+' ***',fanart=params['thumbnail'],thumbnail=params['thumbnail'],isPlayable=False,folder=False);
 body=curl_frame(burl,burl,'');r='popUp\(\'([^\']+).*?src="([^"]+)';w=plugintools.find_multiple_matches(body,r);
 for x in w:
  tit=x[0].split('/')[-1].replace('-',' ').split('.')[0].upper();url=x[0].replace('..',barl);
  plugintools.add_item(title=tit,action='ptc1',url=url,thumbnail=x[1],fanart=x[1],isPlayable=True,folder=False);
 
def ptc1(params):
 url='plugin://plugin.video.SportsDevil/?mode=1&amp;item=title%3d'+params['title']+'%26catcher%3dstreams%26url='+params['url']+'%26referer='+burl;play(url)
		
def curl_frame(url,ref,body):
 request_headers=[];request_headers.append(["User-Agent","Chrome/26.0.1410.65 Safari/537.31","Referer",ref])
 body,response_headers=plugintools.read_body_and_headers(url,headers=request_headers);
 return body