# -*- coding: utf-8 -*-
#--------------------------------------------------------
#  Movie Ultra 7K
# (http://forum.rojadirecta.es
# (http://xbmcspain.com/
# Version 0.0.1 (12.11.2014)
#   !!! Intentar NO compartir este archivo !!!
#--------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
#--------------------------------------------------------
from __main__ import *
ua='User-Agent: Dalvik/1.6.0 (Linux; U; Android 4.0.4; GT-N7000 Build/IMM76L)'
url='http://www.5engines.com'
post='/app_notice.php'
vurl='http://www.vuplus.com'
ua2='Apache-HttpClient/UNAVAILABLE (java 1.4)'
auth='Basic cm9vdDo='
ip='http://62.195.240.181'
ip='http://85.59.71.212'
ip='http://85.59.122.162'
#http://85.60.200.149/doc/page/main.asp admin,1234 hikvision
ip='http://85.60.246.154'
ip='http://62.195.240.181'
#host=ip+':80/web/getservices'
host=ip+':80/web/getservices'
playhost=ip+':8001/'
ua3='VLC/3.0.0-git LibVLC/3.0.0-git'
epg='/ajax/epgpop?sref='
drbox=xbmc.translatePath(os.path.join('special://home/addons/'+xbmcaddon.Addon().getAddonInfo("id")+'/playlists/webif.m3u8'));

def webif0(params):
 body=plugintools.read(url+'/vuplus_app_version.html');heads=[];heads.append(['Authorization',auth]);heads.append(['User-Agent',ua2])
 body,resp=plugintools.read_body_and_headers(host,post='',headers=heads,timeout=30);
 r='<e2service>(.*?)<\/e2service>';body=plugintools.find_multiple_matches(body,r);
 for b in body:
  r='<e2service(reference|name)>([^<]+)';w=plugintools.find_multiple_matches(b,r);
  plugintools.add_item(action='webif1',title=w[1][1],url=w[0][1],thumbnail=params['thumbnail'],fanart=params['thumbnail'],isPlayable=False,folder=True)
def webif1(params):
 heads=[];heads.append(['Authorization',auth]);heads.append(['User-Agent',ua2])
 body,resp=plugintools.read_body_and_headers(host+'?sRef='+urllib.quote_plus(params['url']),post='',headers=heads,timeout=30);
 r='<e2service>(.*?)<\/e2service>';body=plugintools.find_multiple_matches(body,r);
 for b in body:
  r='<e2service(reference|name)>([^<]+)';w=plugintools.find_multiple_matches(b,r);
  plugintools.add_item(action='webif2',title=w[1][1],url=w[0][1],thumbnail=params['thumbnail'],fanart=params['thumbnail'],isPlayable=True,folder=False)
   
def webif2(params):
 iks=ip+'/web/stream.m3u?ref='+params['url']+'&name='+urllib.quote_plus(params['title']);
 heads=[];heads.append(['Authorization',auth]);heads.append(['User-Agent',ua3]);heads.append(['Icy-MetaData','1'])
 body,resp=plugintools.read_body_and_headers(iks,headers=heads,timeout=30);print heads
 opt='\n#EXTVLCOPT:http-caching=1200\n#EXTVLCOPT:http-user-agent='+ua3;
 try:file=open(drbox,'w');file.write('#EXTM3U');file.close();file=open(drbox,'a');file.write(opt);file.write(body.replace('#EXTM3U',''));file.close();
 except:print "Can't create .m3u8 for "+iks;
 #plugintools.play_resolved_url(playhost.replace('http','rtp')+params['url'])
 plugintools.play_resolved_url(playhost+params['url'])
 plugintools.direct_play(drbox)
 plugintools.play_resolved_url(iks)
 plugintools.play_resolved_url(drbox)
 #plugintools.play_resolved_url(playhost.replace('http','rtp')+params['url'])
 try:plugintools.play_resolved_url(iks)
 except:
  try:plugintools.play_resolved_url(playhost+params['url'])
  except:eval(nolink)