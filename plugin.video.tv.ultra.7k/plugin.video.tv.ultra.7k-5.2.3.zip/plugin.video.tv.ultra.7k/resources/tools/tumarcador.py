# -*- coding: utf-8 -*-
#------------------------------------------------------------

#------------------------------------------------------------


import os
import xbmcplugin
import xbmc, xbmcgui
import urllib

import sys
import urllib
import urllib2
import re

import xbmcaddon

import plugintools
import requests

from resources.tools.resolvers import *
from resources.tools.media_analyzer import *

playlists = xbmc.translatePath(os.path.join('special://userdata/playlists', ''))
temp = xbmc.translatePath(os.path.join('special://userdata/playlists/tmp', ''))

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")


parser="[COLOR skyblue][B]Eventos Deportivos TuMarcador HD[/B][/COLOR]"
autor="[COLOR yellow][B][I][/I][/B][/COLOR]"
url_ref = "http://tumarcador.xyz/"
url_montada = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=MI_CANAL%26referer='+url_ref

url = "http://tumarcador.xyz"


def tumarcador0(params):
	headers = {"User-Agent": 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:41.0) Gecko/20100101 Firefox/41.0', "Referer": url}
	r=requests.get(url, headers=headers)
	data = r.content

	logo = "https://pbs.twimg.com/profile_images/1851363673/logo.jpg"
	fondo = "http://www.eliberico.com/wp-content/uploads/2016/03/futbol_spanish_connection.jpg"
	
	plugintools.add_item(action="",url="",title="               "+parser+autor,thumbnail=logo,fanart=fondo,folder=False,isPlayable=False)
	plugintools.add_item(action="",url="",title="",thumbnail=logo, fanart=fondo, folder=False, isPlayable=False)
	
	plugintools.add_item(action="marca_zaping",url="",title="[COLOR aqua][B][I]-Canales Tumarcador[/I][/B][/COLOR]",thumbnail="http://i.imgur.com/kV5iL0j.png", fanart="http://www.elcambur.com.ve/elcambur/wp-content/uploads/Final-mundial-collage.png", folder=True, isPlayable=True)
	plugintools.add_item(action="",url="",title="",thumbnail=logo, fanart=fondo, folder=False, isPlayable=False)

	dias = plugintools.find_multiple_matches(data,'col-md-12">(.*?)</div>')  # Cojo los bloques de los diferentes días
	
	for item in dias:
		dia = plugintools.find_single_match(item,'<h2>(.*?)</h2>')  # Cojo el día
		if len(dia) <> 0:
			plugintools.add_item(action="",url="",title="[COLOR lime][B][I]           ····"+dia+"····[/COLOR][/B][/I]",thumbnail=logo,fanart=fondo,folder=False,isPlayable=False)
				
		eventos = plugintools.find_multiple_matches(item,'">(.*?)<')  # Cojo los diferentes partidos con hora, encuentro y canal
		for item2 in eventos:
			#Vamos a separar la hora (si la tiene), el partido y el canal
			#13:00 CELTA - AT. MADRID - CANAL 1   o sin Hora:
			# US OPEN - CANAL 6
			item2 = "COMIENZO" + item2 + "FINAL"
			provisional = item2.replace(" ", "<").upper()
			if ":" in item2:  # Si tiene horario... hay veces que no ponen hora en la web
				hora = plugintools.find_single_match(provisional,'COMIENZO(.*?)<')+"->"  # Cojo la hora
			else:
				hora = "-"
				
			if hora == "-":
				partido = plugintools.find_single_match(item2,'COMIENZO(.*?)- CANAL').strip()  # Cojo el partido
			else:
				partido = plugintools.find_single_match(provisional,'<(.*?)-<CANAL')  # Cojo el partido
				
			canal = "Canal "+plugintools.find_single_match(item2,'CANAL(.*?)FINAL')  # Cojo el canal
			
			#Lo formateo para la presentación
			hora = "[COLOR red]"+hora
			#Quito el signo "<" q me sirvió para las separaciones y lo pongo en formato title().. ej: Celta - At. Madrid
			partido = "[COLOR yellow]" + ( partido.replace("<", " ").title() )
			num_canal = canal.replace("Canal ", "").strip()
			canal = "[COLOR red][I]"+canal+"[/I][/COLOR]"
			
			linea = hora + "  " + partido + "       " + canal
			linea = linea.strip()  # elimino posibles espacios a izq. y derecha por si no trae hora la línea
			
			#Preparo la url del canal para después lanzarlo con el SportsDevil (me ahorro tener que sacar el regex jejeje
			#http://tumarcador.xyz/canal1.php
			url_canal = "http://tumarcador.xyz/canal" + num_canal + ".php"
			lanzo_spd = url_montada.replace("MI_CANAL", url_canal)
			
			#Montamos la línea.
			plugintools.add_item(action="lanza_marca",url=lanzo_spd,title=linea,thumbnail=logo,fanart=fondo,folder=False,isPlayable=True)
			
			
			
			
def marca_zaping(params):
	headers = {"User-Agent": 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:41.0) Gecko/20100101 Firefox/41.0', "Referer": url}
	r=requests.get(url, headers=headers)
	data = r.content

	logo = "https://pbs.twimg.com/profile_images/1851363673/logo.jpg"
	fondo = "http://www.sportyou.es/blog/wp-content/uploads/2016/09/Neymar-Benzema-Cristiano.jpg"

	plugintools.add_item(action="",url="",title="                  "+parser+"[COLOR yellow]  [/COLOR]",thumbnail=logo,fanart=fondo,folder=False,isPlayable=False)
	plugintools.add_item(action="",url="",title="",thumbnail=logo, fanart=fondo, folder=False, isPlayable=False)
	
	canales = plugintools.find_single_match(data,'dropdown-menu">(.*?)</ul>')  # Cojo el bloque de canales
	cada_canal = plugintools.find_multiple_matches(canales,'href="(.*?)"')  # Separo todos los canales y los monto en su url
				
	#Los saco a pantalla
	for item in cada_canal:
		titulo = "[COLOR aqua]- Ver el Canal " + plugintools.find_single_match(item,'canal(.*?)php').replace(".", "") + "[/COLOR]"

		el_canal = "http://tumarcador.xyz/" + item
		lanzo_spd = url_montada.replace("MI_CANAL", el_canal)
		
		#Montamos la línea.
		plugintools.add_item(action="lanza_marca",url=lanzo_spd,title=titulo,thumbnail=logo,fanart=fondo,folder=False,isPlayable=True)



def lanza_marca(params):
	lanzame = 'PlayMedia(' + params.get("url") + ')'


	xbmc.executebuiltin(lanzame)
	
	
	
	
